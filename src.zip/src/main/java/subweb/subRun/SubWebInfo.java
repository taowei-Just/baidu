package subweb.subRun;

public class SubWebInfo {
    public String startD = "";
    public String endD = "";
    public boolean coner = true;

    @Override
    public String toString() {
        return "SubWebInfo{" +
                "startD='" + startD + '\'' +
                ", endD='" + endD + '\'' +
                ", coner=" + coner +
                '}';
    }
}
