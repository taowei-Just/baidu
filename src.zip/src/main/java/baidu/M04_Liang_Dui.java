package baidu;

import baidu.Ecai.Main;

public class M04_Liang_Dui {
    public static void main(String[] args) {
        Main.Info info3 = new Main.Info();
        info3.account = "wtw960401";
        info3.password = "953934cap";
        info3.indede = 4;
        info3.ticketKind = 1;
        info3.tag = "_San_tiao_04_";
        info3.dub = 3;
        info3.mulripe = 1;
        info3.precent=0.5;
        info3.minIss = 70;
        info3.expectW =10 ;
        info3.ticketKind =1;
        new Main().start(info3);
    }

}
