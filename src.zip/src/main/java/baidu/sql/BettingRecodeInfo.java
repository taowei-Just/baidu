package baidu.sql;

public class BettingRecodeInfo {
    
    public  String time ;
    public  String issue ;
    public  String money ;
    public  String  present ;
    public  String   dub;
    public  String   account;
    public  String   ticketKind;
    public  String   mulripe;
    public  String   indede;
    public  String   indeDetail;
}
