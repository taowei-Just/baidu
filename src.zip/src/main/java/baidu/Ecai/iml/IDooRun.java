package baidu.Ecai.iml;

public interface IDooRun  {
    void start();
}
