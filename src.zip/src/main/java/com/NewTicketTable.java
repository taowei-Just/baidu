package com;

public class NewTicketTable {


    public int totalMoney;
    public  int tou_wutiao;
    public int tou_zadan;
    public int tou_hulu;
    public int tou_shunzi;
    public  int tou_santiao;
    public  int tou_liangdui;
    public  int tou_dandui;
    public int tou_sanhao;

    public double wutiao_yingli;
    public  double zadan_yingli;
    public  double hulu_yingli;
    public double shunzi_yignli;
    public  double santiao_yingli;
    public  double liangdui_yingli;
    public double dandui_yingli;
    public  double sanhao_yingli;

    public  double wutiao_winRatio;
    public   double zadan_winRatio;
    public   double hulu_winRatio;
    public  double shunzi_winRatio;
    public double santiao_winRatio;
    public double liangdui_winRatio;
    public double dandui_winRatio;
    public double sanhao_winRatio;
    public  String congrats ;

    @Override
    public String toString() {
        return "NewTicketTable{" +
                "congrats='" + congrats + '\'' +
                ", totalMoney=" + totalMoney +
                ", tou_wutiao=" + tou_wutiao +
                ", tou_zadan=" + tou_zadan +
                ", tou_hulu=" + tou_hulu +
                ", tou_shunzi=" + tou_shunzi +
                ", tou_santiao=" + tou_santiao +
                ", tou_liangdui=" + tou_liangdui +
                ", tou_dandui=" + tou_dandui +
                ", tou_sanhao=" + tou_sanhao +
                ", wutiao_yingli=" + wutiao_yingli +
                ", zadan_yingli=" + zadan_yingli +
                ", hulu_yingli=" + hulu_yingli +
                ", shunzi_yignli=" + shunzi_yignli +
                ", santiao_yingli=" + santiao_yingli +
                ", liangdui_yingli=" + liangdui_yingli +
                ", dandui_yingli=" + dandui_yingli +
                ", sanhao_yingli=" + sanhao_yingli +
                ", wutiao_winRatio=" + wutiao_winRatio +
                ", zadan_winRatio=" + zadan_winRatio +
                ", hulu_winRatio=" + hulu_winRatio +
                ", shunzi_winRatio=" + shunzi_winRatio +
                ", santiao_winRatio=" + santiao_winRatio +
                ", liangdui_winRatio=" + liangdui_winRatio +
                ", dandui_winRatio=" + dandui_winRatio +
                ", sanhao_winRatio=" + sanhao_winRatio +
                '}';
    }
}
