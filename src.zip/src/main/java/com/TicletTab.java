package com;

public class TicletTab {

    int touzhu_wutiao;
    int touzhu_zadan;
    int touzhu_hulu;
    int touzhu_shunzi;
    int touzhu_santiao;
    int touzhu_liangdui;
    int touzhu_dandui;
    int touzhu_sanhao;

    double wutiao_zhongjiang_yingli;
    double wutiao_zhongjiang_kuisun;
    double zadan_zhongjiang_yingli;
    double zadan_zhongjiang_kuisun;
    double hulu_zhongjiang_yingli;
    double hulu_zhongjiang_kuisun;
    double shunzi_zhongjiang_yignli;
    double shunzi_zhongjiang_kuisun;
    double santiao_zhongjiang_yingli;
    double santiao_zhongjiang_kuisun;
    double liangdui_zhongjiang_yingli;
    double liangdui_zhongjiang_kuisun;
    double dandui_zhongjiang_yingli;
    double dandui_zhongjiang_kuisun;
    double sanhao_zhongjiang_yingli;
    double sanhao_zhongjiang_kuisun;

    public void setTouzhu_wutiao(int touzhu_wutiao) {
        this.touzhu_wutiao = touzhu_wutiao;
    }

    public void setTouzhu_zadan(int touzhu_zadan) {
        this.touzhu_zadan = touzhu_zadan;
    }

    public void setTouzhu_hulu(int touzhu_hulu) {
        this.touzhu_hulu = touzhu_hulu;
    }

    public void setTouzhu_shunzi(int touzhu_shunzi) {
        this.touzhu_shunzi = touzhu_shunzi;
    }

    public void setTouzhu_santiao(int touzhu_santiao) {
        this.touzhu_santiao = touzhu_santiao;
    }

    public void setTouzhu_liangdui(int touzhu_liangdui) {
        this.touzhu_liangdui = touzhu_liangdui;
    }

    public void setTouzhu_dandui(int touzhu_dandui) {
        this.touzhu_dandui = touzhu_dandui;
    }

    public void setTouzhu_sanhao(int touzhu_sanhao) {
        this.touzhu_sanhao = touzhu_sanhao;
    }

    public void setWutiao_zhongjiang_yingli(double wutiao_zhongjiang_yingli) {
        this.wutiao_zhongjiang_yingli = wutiao_zhongjiang_yingli;
    }

    public void setWutiao_zhongjiang_kuisun(double wutiao_zhongjiang_kuisun) {
        this.wutiao_zhongjiang_kuisun = wutiao_zhongjiang_kuisun;
    }

    public void setZadan_zhongjiang_yingli(double zadan_zhongjiang_yingli) {
        this.zadan_zhongjiang_yingli = zadan_zhongjiang_yingli;
    }

    public void setZadan_zhongjiang_kuisun(double zadan_zhongjiang_kuisun) {
        this.zadan_zhongjiang_kuisun = zadan_zhongjiang_kuisun;
    }

    public void setHulu_zhongjiang_yingli(double hulu_zhongjiang_yingli) {
        this.hulu_zhongjiang_yingli = hulu_zhongjiang_yingli;
    }

    public void setHulu_zhongjiang_kuisun(double hulu_zhongjiang_kuisun) {
        this.hulu_zhongjiang_kuisun = hulu_zhongjiang_kuisun;
    }

    public void setShunzi_zhongjiang_yignli(double shunzi_zhongjiang_yignli) {
        this.shunzi_zhongjiang_yignli = shunzi_zhongjiang_yignli;
    }

    public void setShunzi_zhongjiang_kuisun(double shunzi_zhongjiang_kuisun) {
        this.shunzi_zhongjiang_kuisun = shunzi_zhongjiang_kuisun;
    }

    public void setSantiao_zhongjiang_yingli(double santiao_zhongjiang_yingli) {
        this.santiao_zhongjiang_yingli = santiao_zhongjiang_yingli;
    }

    public void setSantiao_zhongjiang_kuisun(double santiao_zhongjiang_kuisun) {
        this.santiao_zhongjiang_kuisun = santiao_zhongjiang_kuisun;
    }

    public void setLiangdui_zhongjiang_yingli(double liangdui_zhongjiang_yingli) {
        this.liangdui_zhongjiang_yingli = liangdui_zhongjiang_yingli;
    }

    public void setLiangdui_zhongjiang_kuisun(double liangdui_zhongjiang_kuisun) {
        this.liangdui_zhongjiang_kuisun = liangdui_zhongjiang_kuisun;
    }

    public void setDandui_zhongjiang_yingli(double dandui_zhongjiang_yingli) {
        this.dandui_zhongjiang_yingli = dandui_zhongjiang_yingli;
    }

    public void setDandui_zhongjiang_kuisun(double dandui_zhongjiang_kuisun) {
        this.dandui_zhongjiang_kuisun = dandui_zhongjiang_kuisun;
    }

    public void setSanhao_zhongjiang_yingli(double sanhao_zhongjiang_yingli) {
        this.sanhao_zhongjiang_yingli = sanhao_zhongjiang_yingli;
    }

    public void setSanhao_zhongjiang_kuisun(double sanhao_zhongjiang_kuisun) {
        this.sanhao_zhongjiang_kuisun = sanhao_zhongjiang_kuisun;
    }

    public int getTouzhu_wutiao() {
        return touzhu_wutiao;
    }

    public int getTouzhu_zadan() {
        return touzhu_zadan;
    }

    public int getTouzhu_hulu() {
        return touzhu_hulu;
    }

    public int getTouzhu_shunzi() {
        return touzhu_shunzi;
    }

    public int getTouzhu_santiao() {
        return touzhu_santiao;
    }

    public int getTouzhu_liangdui() {
        return touzhu_liangdui;
    }

    public int getTouzhu_dandui() {
        return touzhu_dandui;
    }

    public int getTouzhu_sanhao() {
        return touzhu_sanhao;
    }

    public double getWutiao_zhongjiang_yingli() {
        return wutiao_zhongjiang_yingli;
    }

    public double getWutiao_zhongjiang_kuisun() {
        return wutiao_zhongjiang_kuisun;
    }

    public double getZadan_zhongjiang_yingli() {
        return zadan_zhongjiang_yingli;
    }

    public double getZadan_zhongjiang_kuisun() {
        return zadan_zhongjiang_kuisun;
    }

    public double getHulu_zhongjiang_yingli() {
        return hulu_zhongjiang_yingli;
    }

    public double getHulu_zhongjiang_kuisun() {
        return hulu_zhongjiang_kuisun;
    }

    public double getShunzi_zhongjiang_yignli() {
        return shunzi_zhongjiang_yignli;
    }

    public double getShunzi_zhongjiang_kuisun() {
        return shunzi_zhongjiang_kuisun;
    }

    public double getSantiao_zhongjiang_yingli() {
        return santiao_zhongjiang_yingli;
    }

    public double getSantiao_zhongjiang_kuisun() {
        return santiao_zhongjiang_kuisun;
    }

    public double getLiangdui_zhongjiang_yingli() {
        return liangdui_zhongjiang_yingli;
    }

    public double getLiangdui_zhongjiang_kuisun() {
        return liangdui_zhongjiang_kuisun;
    }

    public double getDandui_zhongjiang_yingli() {
        return dandui_zhongjiang_yingli;
    }

    public double getDandui_zhongjiang_kuisun() {
        return dandui_zhongjiang_kuisun;
    }

    public double getSanhao_zhongjiang_yingli() {
        return sanhao_zhongjiang_yingli;
    }

    public double getSanhao_zhongjiang_kuisun() {
        return sanhao_zhongjiang_kuisun;
    }

    @Override
    public String toString() {
        return "\nTicletTab{" +
                "五条=" + touzhu_wutiao +
                ", 押注炸弹=" + touzhu_zadan +
                ", 押注葫芦=" + touzhu_hulu +
                ", 押注顺子=" + touzhu_shunzi +
                ", 押注三条=" + touzhu_santiao +
                ", 押注两对=" + touzhu_liangdui +
                ", 押注单对=" + touzhu_dandui +
                ", 押注散号" + touzhu_sanhao +
                "\n, wutiao收益=" + wutiao_zhongjiang_yingli +
                ", zadan收益=" + zadan_zhongjiang_yingli +
                ", hulu收益=" + hulu_zhongjiang_yingli +
                ", shunzi收益=" + shunzi_zhongjiang_yignli +
                "\n, santiao收益=" + santiao_zhongjiang_yingli +
                ", liangdui收益=" + liangdui_zhongjiang_yingli +
                ", dandui_收益=" + dandui_zhongjiang_yingli +
                ", sanhao_收益=" + sanhao_zhongjiang_yingli +

                '}';
    }
}
